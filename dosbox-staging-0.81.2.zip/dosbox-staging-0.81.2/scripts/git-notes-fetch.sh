#!/bin/bash

# We store additional metadata in the notes (e.g. URLs to Vogons forum
# or SourceForge issue tracker)
git fetch origin refs/notes/*:refs/notes/*
