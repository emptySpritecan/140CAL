You need to download the following tools:
- uconv (contained in the ICU package): https://github.com/unicode-org/icu/releases/latest
- dos2unix: https://dos2unix.sourceforge.io/
Extract the following files in the "\tools" folder:
	uconv.exe (and its dlls)
	dos2unix.exe
