You need to download the following tools:
  - uconv (contained in the ICU package): https://github.com/unicode-org/icu/releases/latest
  - File (Unix tool) for Windows: http://downloads.sourceforge.net/gnuwin32/file-5.03-bin.zip
    and its dependencies: http://downloads.sourceforge.net/gnuwin32/file-5.03-dep.zip
Extract the following files in the "\tools" folder:
    From the ICU zip package                (bin folder): uconv.exe and dlls
    From the File tool zip package          (bin folder): file.exe, magic1.dll
                                     (share\misc folder): magic
    From the File tool dependencies package (bin folder): regex2.dll, zlib1.dll
